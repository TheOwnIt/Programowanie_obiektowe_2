#include <iostream>
#include <string>

using namespace std;

class towar{
	public:
		
	int ilosc;	
	
};
