#include <iostream>
#include <string>

using namespace std;

class magazyn{
	public:
		
	string name;
	int ilosc_kontener;	
	
};
