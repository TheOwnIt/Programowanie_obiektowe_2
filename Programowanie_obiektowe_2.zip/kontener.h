#include <iostream>
#include <string>

using namespace std;

class kontener{
	public:
	int ilosc;	
	
};
